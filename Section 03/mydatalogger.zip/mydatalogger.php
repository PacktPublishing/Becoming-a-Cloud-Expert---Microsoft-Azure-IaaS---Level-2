<html>
<head>
</head>
<body>
   <h1>Arduino Sensors Data</h1>
   <h3>Temperature and Humidity Reading</h3>
   <table border="1" cellspacing="1" cellpadding="1">
		<tr>
			<td>&nbsp;Timestamp&nbsp;</td>
			<td>&nbsp;Temperature &nbsp;</td>
			<td>&nbsp;Humidity &nbsp;</td>			
		</tr>

<?php
		$servername="10.0.0.4";
		$username="idan";
		$password="idanpass";
		$dbname="mydatabase";

		// Create connection   	
		$dblink = mysqli_connect($servername, $username, $password,$dbname);
		// Check connection
		if (!$dblink) {
			die("connection failed!: " . mysqli_connect_error());
		}
		echo "connected successfully to the database <br>";	
	$query="SELECT * FROM dht11_logs ORDER BY timestamp ASC";
	
	if ($result=mysqli_query($dblink, $query)) {
		echo "reading records successfully from dht11_logs <br>";
	} else {
		echo "Error: " . $query . "<br>" . mysqli_error($dblink);
	} 
		  if(mysqli_num_rows($result) > 0){
		     while($row = mysqli_fetch_assoc($result)) {
		        printf("<tr>
					<td> &nbsp;%s </td>
					<td> &nbsp;%s&nbsp; </td>
					<td> &nbsp;%s&nbsp; </td>
					</tr>", 
		           $row["timestamp"], $row["temperature"], $row["humidity"]);
		     }
		  }
		  mysqli_close($dblink);
      ?>
   </table>
</body>
</html>
